import javax.swing.*;
import javax.swing.ImageIcon;
import java.awt.*;
import java.awt.event.*;
import javax.swing.JFrame;
import javax.swing.WindowConstants;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.io.File;

public class abc3 extends JFrame implements ActionListener
{
	JFrame f2;
	JScrollPane jp;
	TextArea j11;
	abc3()
	{
		f2=new JFrame("Viewer");
		f2.setSize(1200,700);
		f2.setLayout(null);
		f2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f2.setVisible(true);
		
		JButton b4=new JButton("Back");
		b4.setBounds(1025,25,80,60);
		f2.add(b4);
		b4.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e)
				{
					abc ob1=new abc();
					ob1.f1.setVisible(true);
					f2.dispose();
				}
			});
		
				j11=new TextArea(" ");
				j11.setBounds(50,85,1100,700);
				
				f2.add(j11);
			
		
				
			try{
				
				File file=new File("F:\\AIUB\\java\\Project\\test\\test.txt");
				Scanner scanner= new Scanner(file);
				
				while(scanner.hasNext()){
					String rb=scanner.nextLine();
					String tt=scanner.nextLine();
					String tn=scanner.nextLine();
					String ts=scanner.nextLine();
					String as=scanner.nextLine();
					String it=scanner.nextLine();
					j11.setText("Registred By: "+rb+"\nTransport Type: "+tt+"\nTransport Name: "+tn+"\nTransport Seat: "+ts+"\nAvailable Seat: "+as+"\nIssued Time: "+it);
				}
				scanner.close();
				
			} catch(Exception e){
				return;
			}	
							
			
		JLabel background1; 
        ImageIcon img15 = new ImageIcon("Image1.jpg");
		background1 = new JLabel("",img15,JLabel.CENTER);   
		background1.setBounds(0,0,1250,1100);    
		//f2.add(background1);
		
		jp= new JScrollPane(j11);
		jp.setBounds(0,0,1180,660);
		f2.add(jp);
		
		
	}
	
	
	public void actionPerformed(ActionEvent e)
	{
		
			
	}
	
	
	
	
	
	
	
	
	
	
	
	
}