import javax.swing.*;
import javax.swing.ImageIcon;
import java.awt.*;
import java.awt.event.*;
import javax.swing.JFrame;
import javax.swing.WindowConstants;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;




public class abc2 extends JFrame implements ActionListener
{
	JFrame f;
	JButton b1;
	JButton b2;
	JButton b3;
	JButton b4;
	JTextField  t1;
	JTextField  t2;
	JTextField  t3;
	JTextField  t4;
	JTextField  t5;
	JTextField  t6;
	private JButton ButtonYes;
	
	 private ImageIcon img;
	 JLabel background; 
	public abc2()
	{
			JPanel PanelForm1=new JPanel();
			
			JRadioButton radio1, radio2, radio3;
			
			f= new JFrame("Register");
			f.setSize(1200,700);
			f.setLayout(null);
			f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			f.setVisible(true);
			
		
			JLabel l4=new JLabel("Registred by :");
			l4.setBounds(50,50,200,150);//(x,y,w,h)
			f.add(l4);
			Font fn1=new Font("Arial", Font.PLAIN, 20);
			l4.setFont(fn1);
		
			t1=new JTextField();
			t1.setBounds(210,100,400,40);
			f.add(t1);
			t1.setText(" ");
			t1.setPreferredSize(new Dimension(30,20));
			t1.setFont(new Font("Consolas", Font.PLAIN,20));
		
			JLabel l5=new JLabel("Transport Type: ");
			l5.setBounds(50,108,200,150);
			f.add(l5);
			Font fn2=new Font("Arial", Font.PLAIN, 20);
			l5.setFont(fn2);
			
			t2=new JTextField();
			t2.setBounds(210,160,400,40);
			f.add(t2);
			t2.setText(" ");
			t2.setFont(new Font("Consolas", Font.PLAIN,20));
			
			JLabel l6=new JLabel("Transport Name: ");
			l6.setBounds(50,162,200,150);
			f.add(l6);
			Font fn5=new Font("Arial", Font.PLAIN, 20);
			l6.setFont(fn5);
			
			t3=new JTextField();
			t3.setBounds(210,220,400,40);
			f.add(t3);
			t3.setText(" ");
			t3.setFont(new Font("Consolas", Font.PLAIN,20));
			
			JLabel l7=new JLabel("Total Seat : ");
			l7.setBounds(50,220,200,150);
			f.add(l7);
			Font fn6=new Font("Arial", Font.PLAIN, 20);
			l7.setFont(fn6);
			
			t4=new JTextField();
			t4.setBounds(210,277,60,30);
			f.add(t4);
			t4.setText(" ");
			t4.setFont(new Font("Consolas", Font.PLAIN,20));
			
			JLabel l8=new JLabel("Available Seat : ");
			l8.setBounds(50,275,200,150);
			f.add(l8);
			Font fn7=new Font("Arial", Font.PLAIN, 20);
			l8.setFont(fn7);
			
			t5=new JTextField();
			t5.setBounds(210,330,60,30);
			f.add(t5);
			t5.setText(" ");
			t5.setFont(new Font("Consolas", Font.PLAIN,20));
			
			
			JLabel l9=new JLabel("Issued Time : ");
			l9.setBounds(50,335,200,150);
			f.add(l9);
			Font fn8=new Font("Arial", Font.PLAIN, 20);
			l9.setFont(fn8);
			
			t6=new JTextField();
			t6.setBounds(210,395,400,40);
			f.add(t6);
			t6.setText("Hour"+" / "+"Minutes"+" / "+"AM/PM");
			t6.setFont(new Font("Consolas", Font.PLAIN,20));
			
			JLabel l10=new JLabel("Suggestion : ");
			l10.setBounds(50,400,200,150);
			f.add(l10);
			Font fn9=new Font("Arial", Font.PLAIN, 20);
			l10.setFont(fn9);
			
			JRadioButton s1 =new JRadioButton("This route is safe to use.");
			s1.setBounds(200,450, 200,50);
			f.add(s1);
			s1.setForeground(Color.green);
			
			
			
			JRadioButton s2 =new JRadioButton("Better avoid this route.");
			s2.setBounds(200,500, 200,50);
			f.add(s2);
			s2.setForeground(Color.orange);
			
			
			JRadioButton s3 =new JRadioButton("This route is not safe to use.");
			s3.setBounds(200,550, 200,50);
			f.add(s3);
			s3.setForeground(Color.red);
			
			ButtonGroup bg1= new ButtonGroup();
			bg1.add(s1);
			bg1.add(s2);
			bg1.add(s3);
			
		
			
			JButton b4=new JButton("Back");
			b4.setBounds(25,25,80,60);
			f.add(b4);
			b4.addActionListener(new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						
						abc ob1=new abc();
						ob1.f1.setVisible(true);
						f.dispose();
		 
					}
				});
			
			
			JButton b5=new JButton("Save Info");
			b5.setBounds(1025,25,140,60);
			f.add(b5);
			b5.addActionListener(new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						JOptionPane.showMessageDialog(null,"Your Info is saved");
						//BuffferedWriter writer =new BufferedWriter(new FileWriter("output.txt"));
						try{
							BufferedWriter bw= new BufferedWriter(new FileWriter("F:\\AIUB\\java\\Project\\test\\test.txt"));
							String input=t1.getText();
							String input1=t2.getText();
							String input2=t3.getText();
							String input3=t4.getText();
							String input4=t5.getText();
							String input5=t6.getText();
							abc3 obj2=new abc3();
							obj2.j11.setText(t1.getText()+"\n\t"+t2.getText()+"\n\t"+t3.getText()+"\n\t"+t4.getText()+"\n\t"+t5.getText()+"\n\t"+t6.getText()+"\n\t");
							obj2.f2.setVisible(false);
							abc ob1=new abc();
							ob1.f1.setVisible(true);
							f.dispose();
							bw.write(t1.getText()+"\n");
							bw.write(t2.getText()+"\n");
							bw.write(t3.getText()+"\n");
							bw.write(t4.getText()+"\n");
							bw.write(t5.getText()+"\n");
							bw.write(t6.getText()+"\n");
							//bw.write("Azim\n");
							//bw.write("Towhid\n");
							bw.close();
						}
						catch(Exception ez)
						{
							ez.printStackTrace();
							return;
						}
					
						
		 
					}
				});
			
			
			 
			
			JLabel background5;
			ImageIcon img5= new ImageIcon("si.png");
			background5 = new JLabel("",img5,JLabel.LEFT);
			background5.setBounds(0,0,200,200);    
			f.add(background5); 
			
			JLabel background2;
			ImageIcon img2= new ImageIcon("rf.png");
			background2 = new JLabel("",img2,JLabel.LEFT);
			background2.setBounds(0,0,1450,100);    
			f.add(background2); 

			JLabel background3;
			ImageIcon img3= new ImageIcon("rf1.jpg");
			background3 = new JLabel("",img3,JLabel.RIGHT);
			background3.setBounds(200,42,900,625);    
			f.add(background3); 
			
			
	
	}
	public void actionPerformed(ActionEvent e)
	{
		
			
	}
}	