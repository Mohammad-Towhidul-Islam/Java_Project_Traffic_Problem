import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Start
{
	public static void main(String[]args)
	{
		abc g=new abc();
	
		
	}
}