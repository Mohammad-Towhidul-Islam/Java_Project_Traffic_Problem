import javax.swing.*;
import javax.swing.ImageIcon;
import java.awt.*;
import java.awt.event.*;
import javax.swing.JFrame;
import javax.swing.WindowConstants;

public class abc3 extends JFrame implements ActionListener
{
	JFrame f2;
	JScrollPane jp;
	
	abc3()
	{
		f2=new JFrame("Viewer");
		f2.setSize(1200,700);
		f2.setLayout(null);
		f2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f2.setVisible(true);
		
		JButton b4=new JButton("Back");
		b4.setBounds(25,25,80,60);
		f2.add(b4);
		b4.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e)
				{
					abc ob1=new abc();
					ob1.f1.setVisible(true);
					f2.dispose();
				}
			});
		
		
			JLabel l11=new JLabel(" ");
			l11.setBounds(0,100,1200,700);
			f2.add(l11);
		
		JLabel background1; 
        ImageIcon img15 = new ImageIcon("Image1.jpg");
		background1 = new JLabel("",img15,JLabel.CENTER);   
		background1.setBounds(0,0,1250,1100);    
		//f2.add(background1);
		
		jp= new JScrollPane(l11);
		jp.setBounds(0,0,1180,660);
		f2.add(jp);
		
		
	}
	
	
	public void actionPerformed(ActionEvent e)
	{
		
			
	}
	
	
	
	
	
	
	
	
	
	
	
	
}