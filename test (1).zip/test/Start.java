public class Start
{
	public static void main(String[]args)
	{
		abc g=new abc();
		//register r= new register();
		
	}
}