import javax.swing.*;
import javax.swing.ImageIcon;
import java.awt.*;
import java.awt.event.*;
import java.util.Scanner; 
public class register extends JFrame  implements ActionListener 
{
	JTextField  t1;
	
	
	
	public register()
	{
		setVisible(true);
		setSize(1200,800);
		setLayout(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		 JLabel l4=new JLabel("Registred by :");
		l4.setBounds(50,75,200,150);//(x,y,w,h)
		add(l4);
		
		t1=new JTextField();
		t1.setBounds(150,135,150,40);
		add(t1);
		t1.setText("Enter Your Name");
		
		
		
		JLabel l5=new JLabel("");
		l5.setBounds(50,100,200,150);
		add(l5);
		
		
	}
	
	public void actionPerformed(ActionEvent e)
	{
		Scanner t1= new Scanner(System.in);
	
		
		JOptionPane.showMessageDialog(null,"Button Pressed");
	}
	
	
}