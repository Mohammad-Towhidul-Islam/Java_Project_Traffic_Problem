import javax.swing.*;
import javax.swing.ImageIcon;
import java.awt.*;
import java.awt.event.*;
import javax.swing.JFrame;
import javax.swing.WindowConstants;

public class abc extends JFrame  implements ActionListener

{
	JFrame f1;
	JButton b1;
	JButton b2;
	JButton b3;
	JTextField  t1;
	JTextField  t2;
	JTextField  t3;
	JTextField  t4;
	JTextField  t5;
	JTextField  t6;
	private JButton ButtonYes;
	
	 private ImageIcon img;
	 JLabel background; 
	 //private Jlabel label3;
	
	public abc()
	{
		
		f1=new JFrame("Start");
		f1.setSize(1200,750);
		f1.setLayout(null);
		f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        /*setSize(1200,800); 
        setLayout(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE); */
        ImageIcon img = new ImageIcon("tj.jpg");
		background = new JLabel("",img,JLabel.RIGHT);   
		background.setBounds(0,0,1200,900); 
		f1.add(background);        
		f1.setVisible(true);
		
		
		
	    JLabel l1=new JLabel("1 :");
		
		
		l1.setBounds(80,215,200,150);//(x,y,w,h)
		f1.add(l1);
		Font fn3=new Font("Arial", Font.PLAIN, 30);
		l1.setFont(fn3);
		
		JLabel l2=new JLabel("2 :");
		l2.setBounds(80,320,200,150);
		f1.add(l2);
		Font fn4=new Font("Arial", Font.PLAIN, 30);
			l2.setFont(fn4);
		
		b1=new JButton("Viewer");
		b1.setBounds(120,370,200,75);
		f1.add(b1);
		b1.addActionListener(new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						abc3 ob2=new abc3();
						ob2.f2.setVisible(true);
						f1.dispose();
		 
					}
				});
		b1.setVisible(true);
		b1.addActionListener(this);
		
		b2=new JButton("Register");
		b2.setBounds(120,265,200,75);
		f1.add(b2);
		b2.setVisible(true);
		b2.addActionListener(this);
	
		
		b3=new JButton("EXIT");
		b3.setBounds(160,500,100,25);
		f1.add(b3);
		b3.setVisible(true);
		b3.addActionListener(this);
		
		JLabel background1; 
        ImageIcon img1 = new ImageIcon("border.jpg");
		background1 = new JLabel("",img1,JLabel.CENTER);   
		background1.setBounds(0,0,1250,1060);    
		f1.add(background1);       	
	}
	public void actionPerformed(ActionEvent e)
	{
		
		if(e.getActionCommand().equals("Register"))
		{
			f1.setVisible(false);
			abc2 ob=new abc2();
			ob.f.setVisible(true);
			f1.dispose();	
		}
		if(e.getActionCommand().equals("EXIT"))
		{
			f1.setVisible(false);
			f1.dispose();
		}
	}
	
	
	
	
}